#!/bin/bash

source .env/bin/activate

logDir="log/"

logFile=$(date '+%Y-%m-%d-%H-%M').log
echo "Log file: $logFile"

mkdir -p $logDir
strawberry server main | tee $logDir/$logFile
