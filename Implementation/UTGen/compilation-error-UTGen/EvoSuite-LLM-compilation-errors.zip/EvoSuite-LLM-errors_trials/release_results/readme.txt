This module is not part of the EvoSuite compilation.
It is used to keep scripts (Python and R) to run experiments and analyze their results.
These experiments are run on the default version of EvoSuite, at each new release.
Results are then exported in HTML format which will be accessible from www.evosuite.org

