In this folder there are files that have been removed from EvoSuite code.
There might be several reasons for why a file was removed.
One is for example experimental code that is not stable, and not used at the moment, which
might become problematic when the package it belongs to needs to be refactored.