package org.evosuite.llm;

public enum Phase {
    NONE, SRC_CODE, NULL
}
