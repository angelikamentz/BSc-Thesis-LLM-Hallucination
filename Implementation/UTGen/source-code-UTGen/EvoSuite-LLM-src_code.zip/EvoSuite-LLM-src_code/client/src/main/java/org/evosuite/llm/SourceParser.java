package org.evosuite.llm;

import java.util.ArrayList;
import java.util.List;
import org.evosuite.Properties;
import org.evosuite.utils.LoggingUtils;
import spoon.Launcher;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.CtType;
import spoon.reflect.factory.Factory;

public class SourceParser {

    List<CtType<?>> allClasses;
    ArrayList<CtMethod<?>> allMethods = new ArrayList<>();

    public SourceParser() {
        final Launcher launcher = new Launcher();
        launcher.addInputResource(Properties.LLM_SOURCE_DIRECTORY);
        launcher.buildModel();
        launcher.getEnvironment().setComplianceLevel(11);
        Factory spoon = launcher.getFactory();
        //        CtModel model = spoon.getModel();
        allClasses = spoon.Type().getAll();
        LoggingUtils.getEvoLogger().info("All classes: " + allClasses.size() + allClasses);

        retrieveAllMethods();
    }

    private void retrieveAllMethods(){
        for (CtType<?> ctType : allClasses) {
//            System.out.println("Class: " + ctType.getQualifiedName());
//            System.out.println("Methods: ");
//            for (CtMethod<?> method : ctType.getMethods().addAll()) {
            allMethods.addAll(ctType.getMethods());
//            }
        }
        LoggingUtils.getEvoLogger().info("All methods: " + allMethods.size() + allMethods);

    }

    public String getMethodBody(String methodName){
        for (CtMethod<?> method : allMethods) {
            if (method.getSimpleName().equals(methodName)) {
                return method.getBody().toString();
            }
        }
        return null;
    }
}
